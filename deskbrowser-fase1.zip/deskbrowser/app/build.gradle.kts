plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "dev.deskbrowser"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.deskbrowser.app"   // nama kode; diganti lewat replica-brand
        minSdk = 33                              // Android 13+
        targetSdk = 35                           // Android 15
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("arm64-v8a") } // mengecilkan APK GeckoView; tambah x86_64 untuk emulator
    }
    buildTypes {
        release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.material3.wsc)
    implementation(libs.compose.icons)
    implementation(libs.activity.compose)
    implementation(libs.coroutines.android)
    implementation(libs.androidx.window)
    implementation(libs.datastore)
    implementation(libs.work.runtime)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.geckoview)   // aktif di Fase 3; di Fase 2 dipakai FakeEngine
}
