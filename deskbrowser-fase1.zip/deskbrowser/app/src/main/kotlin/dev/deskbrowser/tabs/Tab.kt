package dev.deskbrowser.tabs

data class Tab(
    val id: String,
    val url: String = "about:blank",
    val title: String = "",
    val pinned: Boolean = false,
    val isPrivate: Boolean = false,
    val lastActiveAt: Long = 0L
)

/** Urutan tab: tab pin selalu di kiri. Implementasi di Fase 2. */
interface TabController {
    fun newTab(url: String? = null, private: Boolean = false): Tab
    fun closeTab(id: String)
    fun pinTab(id: String, pinned: Boolean)
    fun moveTab(id: String, toIndex: Int)
    fun selectNext()      // Ctrl+Tab
    fun selectPrevious()  // Ctrl+Shift+Tab
}
