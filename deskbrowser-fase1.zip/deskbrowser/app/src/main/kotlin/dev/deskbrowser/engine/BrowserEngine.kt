package dev.deskbrowser.engine

import dev.deskbrowser.adblock.ContentBlocker
import dev.deskbrowser.extensions.ExtensionHost
import kotlinx.coroutines.flow.Flow

/** Abstraksi engine. Implementasi: GeckoEngine (Track A), ChromiumEngine (Track B, nanti). */
interface BrowserEngine {
    val id: String
    suspend fun initialize()
    fun createSession(config: SessionConfig): EngineSession
    val extensions: ExtensionHost
    val contentBlocker: ContentBlocker
}

data class SessionConfig(
    val desktopMode: Boolean = true,      // default permanen: UA + viewport desktop
    val privateMode: Boolean = false,
    val viewportWidthDp: Int? = null      // null = ikuti lebar jendela
)

interface EngineSession {
    val events: Flow<SessionEvent>
    fun loadUrl(url: String)
    fun goBack()
    fun goForward()
    fun reload()
    fun close()
}

sealed interface SessionEvent {
    data class UrlChanged(val url: String) : SessionEvent
    data class TitleChanged(val title: String) : SessionEvent
    data class LoadProgress(val percent: Int) : SessionEvent
    data class BlockedCount(val ads: Int, val trackers: Int) : SessionEvent
    data class ContextMenuRequested(val x: Int, val y: Int, val linkUrl: String?, val imageUrl: String?) : SessionEvent
}
