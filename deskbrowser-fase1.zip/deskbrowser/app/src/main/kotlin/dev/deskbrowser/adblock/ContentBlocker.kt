package dev.deskbrowser.adblock

enum class ResourceType { DOCUMENT, SUBDOCUMENT, SCRIPT, IMAGE, STYLESHEET, XHR, MEDIA, FONT, WEBSOCKET, OTHER }

data class RequestInfo(val url: String, val sourceUrl: String, val type: ResourceType, val thirdParty: Boolean)

sealed interface BlockDecision {
    data object Allow : BlockDecision
    data class Block(val rule: String) : BlockDecision
    data class Redirect(val resourceName: String) : BlockDecision
    data class UpgradeToHttps(val url: String) : BlockDecision
}

/** Fase 3: diimplementasi dengan adblock-rust (JNI) di balik antarmuka ini. */
interface ContentBlocker {
    fun decide(request: RequestInfo): BlockDecision
    fun cosmeticSelectors(pageUrl: String): List<String>
    suspend fun updateFilterLists()
    fun setEnabledForSite(host: String, enabled: Boolean)
}
