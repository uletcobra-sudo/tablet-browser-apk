package dev.deskbrowser.desktop

/** Fase 3: UA + viewport desktop. Fase 2: hanya kontrak. */
interface DesktopModeManager {
    fun userAgent(): String
    fun viewportWidthDp(windowWidthDp: Int): Int
}

/** Fase 2: pemetaan shortcut keyboard fisik ke aksi. */
enum class BrowserAction { NEW_TAB, CLOSE_TAB, NEW_PRIVATE_TAB, NEXT_TAB, PREV_TAB, FOCUS_OMNIBOX, RELOAD, FIND, HISTORY, DOWNLOADS }
