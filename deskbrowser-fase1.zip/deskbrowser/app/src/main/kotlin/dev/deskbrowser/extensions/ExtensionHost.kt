package dev.deskbrowser.extensions

import kotlinx.coroutines.flow.Flow

enum class ExtensionSource { CHROME_WEB_STORE, CRX_FILE, ZIP_FILE, UNPACKED }

data class ExtensionInfo(
    val id: String,
    val name: String,
    val version: String,
    val manifestVersion: Int,        // 2 atau 3
    val enabled: Boolean,
    val permissions: List<String>,
    val source: ExtensionSource,
    val unsupportedApis: List<String> = emptyList()   // ditampilkan di chrome://extensions
)

sealed interface InstallResult {
    data class Success(val info: ExtensionInfo) : InstallResult
    data class NeedsPermissionReview(val info: ExtensionInfo) : InstallResult
    data class Failure(val reason: String) : InstallResult
}

/** Fase 4. Parser CRX2/CRX3 + manifest ada di CrxParser (belum dibuat). */
interface ExtensionHost {
    val installed: Flow<List<ExtensionInfo>>
    suspend fun install(bytesOrPath: String, source: ExtensionSource): InstallResult
    suspend fun setEnabled(id: String, enabled: Boolean)
    suspend fun uninstall(id: String)
    var developerMode: Boolean
}
