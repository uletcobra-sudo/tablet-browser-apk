package dev.deskbrowser.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text

/** Placeholder Fase 1. Fase 2 mengganti isi dengan BrowserShell (TabStrip + Omnibox + WebContent). */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Text("DeskBrowser - Fase 1 skeleton") } }
    }
}
