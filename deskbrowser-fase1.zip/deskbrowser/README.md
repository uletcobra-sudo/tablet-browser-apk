# DeskBrowser (nama kode)

Browser Android kelas desktop untuk tablet. Status: **Fase 1 selesai** (blueprint + skeleton).

- Blueprint: `replica/architecture.md` - Peta: `replica/recon.md` - Matriks fitur: `replica/features.csv`
- Build: buka di Android Studio (JDK 17), isi `geckoview` di `gradle/libs.versions.toml` dari maven.mozilla.org, Sync, Run di emulator tablet 1280x800.
- Keystore rilis tidak pernah dimasukkan ke repo.
