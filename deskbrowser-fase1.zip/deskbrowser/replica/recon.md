# Recon map — DeskBrowser (nama kode, final lewat replica-brand)

Tanggal: 2026-11-21 · Status: Fase 1 · Sumber: dokumentasi publik & repo open-source saja
(tidak ada screenshot, akun, atau kode internal yang dibaca; aturan clean-room replica-recon berlaku).

## Cakupan (Step 1)
- Platform: Android 13–15, tablet landscape + multi-window + DeX.
- Slice: core loop = **buka situs versi desktop → kelola tab → ekstensi jalan → iklan/tracker terblokir**.
- Untuk siapa: pengguna tablet yang ingin pengalaman Chrome PC.
- Yang ditiru adalah *fungsi & pola UX* (Chrome desktop, Brave Shields, Kiwi extension support), bukan kode/aset/nama/logo.

## Sumber publik (Step 2)
| sumber | untuk apa |
| --- | --- |
| Chrome Extensions docs (developer.chrome.com/docs/extensions) | manifest v2/v3, API surface, popup & service worker |
| MDN WebExtensions | kompatibilitas API di engine Gecko |
| Dokumentasi & Javadoc GeckoView (mozilla.github.io/geckoview) | WebExtensionController, ContentBlocking, session settings |
| Repo open-source Brave (brave-core, adblock-rust; MPL-2.0) | pola Shields, format filter, lisensi |
| Repo open-source Kiwi Browser | pola dukungan ekstensi di Chromium Android (cek status repo sebelum bergantung) |
| EasyList / uBlock filter lists | daftar filter + lisensinya |
| Android docs: multi-window, large screens, desktop mode | perilaku resize, keyboard, mouse |

## Inventaris layar (Step 3)
| ID | layar | cara akses | tujuan | komponen kunci | state |
| --- | --- | --- | --- | --- | --- |
| S01 | Shell browser | launch | rumah semua layar | TabStrip, Omnibox, ExtensionToolbar, WebContent | loading, error halaman, offline, split-screen sempit |
| S02 | New Tab Page | Ctrl+T | pintasan & riwayat | grid situs, search box | kosong, terisi |
| S03 | Context menu klik kanan | klik kanan halaman / tab / link | aksi ala PC | MenuPopup | link, gambar, teks terpilih, tab |
| S04 | Halaman ekstensi `chrome://extensions` | menu / URL | kelola ekstensi | ExtensionCard, Toggle, DevModeSwitch | kosong, error manifest, dev mode on/off |
| S05 | Popup ekstensi | klik ikon ekstensi | UI ekstensi | PopupWindow (anchored) | loading, error, ukuran sempit |
| S06 | Dialog instal ekstensi | CWS / .crx / .zip | konfirmasi izin | PermissionList, Dialog | izin berbahaya, gagal verifikasi |
| S07 | Panel Shields per situs | ikon di omnibox | lihat/atur blokir | counter, toggle | on/off, per jenis |
| S08 | Pengaturan | menu | privasi, UA, mesin pencari | SettingsList | — |
| S09 | Riwayat & bookmark | Ctrl+H / Ctrl+Shift+O | cari ulang | list + search | kosong |
| S10 | Unduhan | Ctrl+J | status unduhan | list + progress | berjalan, gagal |

## Alur pengguna (Step 4)
- F01 Buka URL → halaman render desktop: S01. Edge: URL tak valid, HTTP→HTTPS gagal, situs memaksa mobile.
- F02 Kelola tab: S01 (baru, tutup, pin, drag reorder, Ctrl+Tab). Edge: 50+ tab, tutup tab terakhir, restore setelah proses dimatikan sistem.
- F03 Instal dari Chrome Web Store: S01 → halaman CWS → S06 → S04. Edge: ekstensi MV2/MV3, izin tak didukung.
- F04 Instal manual .crx/.zip/unpacked: S04 → picker file → S06. Edge: CRX3 header korup, manifest invalid.
- F05 Pakai popup ekstensi: ikon → S05. Edge: popup lebih lebar dari split-screen.
- F06 Blokir iklan + atur per situs: S01 → S07. Edge: situs rusak karena filter (tombol "matikan untuk situs ini").
- F07 Background play: video diputar → app ke latar. Edge: layar mati, notifikasi media.
- F08 Resize: split-screen / DeX / rotasi tanpa kehilangan state tab.

## Komponen (Step 5)
TabStrip (tab, pin, close, drag, overflow scroll), Omnibox (saran, ikon situs, ikon shields), ExtensionToolbar (ikon + badge), PopupWindow, ContextMenu, Dialog izin, Toggle, SettingsList, Toast/Snackbar.

## Model data (Step 6) — lokal-first, tanpa server
| entitas | field | bukti | keyakinan |
| --- | --- | --- | --- |
| Tab | id, url, title, favicon, pinned, groupId, lastActive, isPrivate, sessionState(blob) | pola Chrome desktop | tinggi |
| Extension | id, name, version, manifestVersion, enabled, permissions[], source(cws/crx/unpacked), installedAt | docs manifest | tinggi |
| FilterList | id, name, url, lastUpdated, enabled, etag | EasyList | tinggi |
| SiteSetting | host, shieldsEnabled, desktopMode, jsAllowed | pola Shields | sedang (tebakan) |
| HistoryEntry / Bookmark / Download | standar | umum | tinggi |

## Yang tidak bisa / tidak akan ditiru (Step 8)
- skip: Brave Rewards/BAT, Wallet, VPN, Leo — jaringan, lisensi, dan layanan milik Brave.
- skip: Chrome Sync / akun Google — layanan Google; sinkronisasi sendiri bisa jadi fase lanjut.
- skip: nama, logo, ikon, copy milik Brave/Kiwi/Chrome/Mozilla (wajib lewat replica-brand).
- risiko hukum: memasang dari Chrome Web Store dari browser non-Chrome — periksa Terms of Service CWS sebelum rilis publik.

## Ukuran (Step 9)
Layar 10 · alur 8 · entitas 5. Bagian tersulit: (1) engine dengan API ekstensi, (2) jembatan API ekstensi ↔ halaman, (3) pemblokiran request tanpa merusak situs.
**Ukuran: XL jika Chromium penuh → rescope ke L dengan engine GeckoView (lihat architecture.md).**
Langkah berikut: `/replica-architect` (sudah dikerjakan di `architecture.md`).
